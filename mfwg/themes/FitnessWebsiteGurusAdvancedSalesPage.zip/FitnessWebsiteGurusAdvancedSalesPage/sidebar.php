<?php
/**
 * The Sidebar containing the main widget area.
 *
 * @package WordPress
 * @subpackage FitnessWebsiteGurus-Blog
 * @since Twenty Eleven 1.0
 */

//$options = twentyeleven_get_theme_options();
//$current_layout = $options['theme_layout'];

//if ( 'content' != $current_layout ) :
?>
<script type="text/ecmascript">
function phonevalid(phone1,phone2,phone3){
	if(phone1.value.length != 3)
	{
		alert("Please enter first three numbers of your phone number.");
		phone1.focus();
		return true;
	}else
	if(phone2.value.length != 3)
	{
		alert("Please enter second set of three numbers of your phone number.");
		phone2.focus();
		return true;
	}else
	if(phone3.value.length != 4)
	{
		alert("Please enter third set of your phone number.");
		phone3.focus();
		return true;
	}else
	return false;
}
function validate_pphone(pphone,val,xval)
{
	if(xval == 1)
	{
		if(val == 1)
		if(pphone.length ==3)
			document.regForm.phone2.focus();
		if(val == 2)
		if(pphone.length ==3)
			document.regForm.phone3.focus();
	}
	else if(xval == 2)
	{
		if(val == 1)
		if(pphone.length ==3)
			document.regForm.wphone2.focus();
		if(val == 2)
		if(pphone.length ==3)
			document.regForm.wphone3.focus();
	}
}
function numbersonly1(e, decimal) {
var key;
var keychar;

if (window.event) {
   key = window.event.keyCode;
}
else if (e) {
   key = e.which;
}
else {
   return true;
}
keychar = String.fromCharCode(key);

if ((key==null) || (key==0) || (key==8) ||  (key==9) || (key==13) || (key==27) ) {
   return true;
}
else if ((("0123456789").indexOf(keychar) > -1)) {
   return true;
}
else if (decimal && (keychar == ".")) { 
  return true;
}
else if (key >= 97 && key <=105) { 
  return true;
}
else
{
	alert("Phone number value must be numeric.\n");
   return false;
}
}
function chkvalid() {
	
	if(document.regForm.free_name.value == "")
	{
		alert("Please Enter Name");
		document.regForm.free_name.focus();
		return false;
	}
	
	if(document.regForm.email.value == "")
	{
		alert("Please Enter Your Contact Email");
		document.regForm.email.focus();
		return false;
	}
		// Start Email Validation
	if(document.regForm.email.value != "")
	{
		var i;
		var input = document.regForm.email.value ;
		var lenth = input.length ;
		var ctr=0 ;
	
		if ( ( document.regForm.email.value.charAt(i) == '!' ) || ( 	document.regForm.email.value.charAt(i) == '#' ) )
	    {
		  alert("Please enter a proper email address") ;
		  document.regForm.email.focus();
	      return false;
	    }
		if (input =="")
		{
			alert("Please enter email address") ;
		    document.regForm.email.focus();
			return false ;
		}
		if(input.length == 40)
		{
			alert("Please enter a proper email address") ;
		    document.regForm.email.focus();
			return false ;
		}
	
		for ( i=0; i < lenth; i++ )
		{
			var oneChar = input.charAt(i) ;
			if(oneChar == "@")
			{
				ctr = ctr+1 ;
			}
			if ( (i == 0 && oneChar == "@") || (i == 0 && oneChar == ".") || 
				( oneChar == " " ) )
			{
				alert ( "This does not seem to be a proper email address" ) ;
		        document.regForm.email.focus();
				return false ;
			}
			if ( (oneChar == "@" && input.charAt(i+1) == ".") || 
				(oneChar == "." && input.charAt(i+1) == "@") ||
				(oneChar == "." && input.charAt(i+1) == ".") )
			{
				alert ( "This does not seem to be a proper email address" ) ;
		        document.regForm.email.focus();
				return false ;
			}
			if( input.indexOf("@") < 2 )
			{
				alert ( "This does not seem to be a proper email address" ) ;
		        document.regForm.email.focus();
				return false ;
			}
			if(input.indexOf(".")<1)
			{
				alert ( "This does not seem to be a proper email address" ) ;
		        document.regForm.email.focus();
				return false ;
			}
			if (ctr > 1)
			{
				alert ( "This does not seem to be a proper email address" ) ;
		        document.regForm.email.focus();
				return false ;
			}
		}
	}	
	//phone
	if(document.regForm.phone1.value == "")
	{
		alert("Please enter first three numbers of your phone number.");
		document.regForm.phone1.focus();
		return false;
	}
	if(document.regForm.phone1.value.length != 3)
	{
		alert("Please enter first three numbers of your phone number.");
		document.regForm.phone1.focus();
		return false;
	}
	if(document.regForm.phone2.value == "")
	{
		alert("Please enter second set of three numbers of your phone number.");
		document.regForm.phone2.focus();
		return false;
	}
	if(document.regForm.phone2.value.length != 3)
	{
		alert("Please enter second set of three numbers of your phone number.");
		document.regForm.phone2.focus();
		return false;
	}
	if(document.regForm.phone3.value == "")
	{
		alert("Please enter third set of your phone number.");
		document.regForm.phone3.focus();
		return false;
	}
	if(document.regForm.phone3.value.length != 4)
	{
		alert("Please enter third set of your phone number.");
		document.regForm.phone3.focus();
		return false;
	}
	//end phone
	document.regForm.submit();
}
</script>
<?php 

if($_SERVER['REQUEST_METHOD'] == "POST" && $_POST["singup"] == 1)
{
	extract($_POST);
	$to=$admin_email = get_settings('admin_email'); 
	$message="<div>
	<p>Name:  ".$name."</p>
	<p>Email: ".$email."</p>
	<p>Phone: ".$phone1."-".$phone2."-".$phone3."</p>
	</div>";
	
	add_filter('wp_mail_content_type',create_function('', 'return "text/html";'));		
	wp_mail( $to, "Contact info from 1 week free trail", $message, $headers); 
}?>
<div id="secondary" class="widget-area" role="complementary"  > 
<aside id="archives" class="getstartedform">  
			<form method="post" name="regForm" id="regForm">
            <input type="hidden" name="singup" value="1">
				<ul>
					<li><p>Just enter your information below and receive a free 1 week trial.</p></li>
					<li><label>Name:</label> <input name="free_name" id="free_name" type="text"></li>
					<li><label>Email:</label><input name="email"  id="email" type="text" ></li>
					<li class="ph"><label>Phone:</label> <input type="text" maxlength="3" name="phone1" tabindex="4" onKeyUp="validate_pphone(this.value,1,1); return numbersonly1(event, false,1)" >
                    <input type="text" maxlength="3" name="phone2" tabindex="5" onKeyUp="validate_pphone(this.value,2,1);return numbersonly1(event, false,1)" /> 
                    <input type="text" maxlength="4" name="phone3" tabindex="6" onKeyUp="return numbersonly1(event, false,1)"  /></li>
					<li><input name="b1" type="button" class="button" onClick="return chkvalid();"></li> 
				</ul> 
			 </form>
		</aside>
	<aside id="profile" class="profile">
		<img src="<?php if(getcustomImage(4)<>'') echo getcustomImage(4); else echo bloginfo('url')."/wp-content/themes/".get_template()."/images/header_images/profile_1.png"?>" />		
		<h2>About</h2>
		<ul><li><?php $activeabout=mysql_fetch_object(mysql_query("select * from `".$wpdb->prefix."custom_contacts` where title='About' and status=1"));
		echo stripslashes($activeabout->content);
		?> </li>
		<li><?php $activeemail=mysql_fetch_object(mysql_query("select * from `".$wpdb->prefix."custom_contacts` where title='Email' and status=1"));
		echo "<strong>Email</strong> : <a href='mailto:".stripslashes($activeemail->content)."'>".stripslashes($activeemail->content)."</a>";
		?> 
		<br> <?php $activephone=mysql_fetch_object(mysql_query("select * from `".$wpdb->prefix."custom_contacts` where title='Phone' and status=1"));
		echo "<strong>Phone Number : </strong>".stripslashes($activephone->content);
		?></li>
		</ul>
	</aside>
	<div class="whline"></div>
	<aside id="tst" class="tst"> 
		<h2>Testimonials</h2>
		<ul>		
		<?php 
		$catid=get_category_by_slug( 'testimonial' );
		//echo $catid->term_id;
		$getTestimonials=mysql_query("SELECT * FROM ".$wpdb->prefix."posts wp, wp_term_relationships wtr WHERE wtr.term_taxonomy_id = ".$catid->term_id." AND object_id = wp.ID order by wp.post_date desc");
		while($fetTestimonials=mysql_fetch_object($getTestimonials)){?>
		<li><p><?php echo $fetTestimonials->post_content?> </p>
			<strong><?php echo $fetTestimonials->testimonial_name?></strong><br>
			<?php echo $fetTestimonials->testimonial_city?>
		</li>
		<?php }?>
		</ul>
	</aside>
				

		</div><!-- #secondary .widget-area -->
<?php //endif; ?>