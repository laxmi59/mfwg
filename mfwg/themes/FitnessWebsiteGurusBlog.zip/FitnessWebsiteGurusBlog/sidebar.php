<?php
/**
 * The Sidebar containing the main widget area.
 *
 * @package WordPress
 * @subpackage FitnessWebsiteGurus-Blog
 * @since Twenty Eleven 1.0
 */

//$options = twentyeleven_get_theme_options();
//$current_layout = $options['theme_layout'];

//if ( 'content' != $current_layout ) :
?>
<script type="text/javascript">
function trimfun(stringToTrim) {
	return stringToTrim.replace(/^\s+|\s+$/g,"");
}
function isNotEmpty(fname,txt){
	if(trimfun(fname.value)==""){
		alert(txt);
		fname.focus();
		return true;
	}else{
		return false;
	}
}
function email(reg)
{
	var e=reg.value;
	var e1=/^(?:\w+\.?)*\w+@(?:\w+\.)+\w+$/;
	if(e.match(e1))
	{
		return false;
	}
	else
	{
		alert("Enter valid Email");
		reg.value="";
		reg.focus();
		return true;
	}
}
function blogPageFreeTrail(reg){
	
	if(isNotEmpty(document.getElementById("free_name"),"Please enter a Name")){return false}
	
	if(isNotEmpty(document.getElementById("free_email"),"Please enter a Email")){return false}
	
	if(email(document.getElementById("free_email"),"Invalid Email")){return false}
	document.getElementById("reg").submit();
} 

</script>
<?php 

if($_SERVER['REQUEST_METHOD'] == "POST" && $_POST["singup"] == 1)
{
	extract($_POST);
	$to=$admin_email = get_settings('admin_email'); 
	$message="<div>
	<p>Name:  ".$free_name."</p>
	<p>Email: ".$free_email."</p>
	</div>";
	
	add_filter('wp_mail_content_type',create_function('', 'return "text/html";'));		
	wp_mail( $to, "Contact information from Free fat loss report", $message, $headers); 
}?>

		<div id="secondary" class="widget-area" role="complementary">
				<aside id="archives" class="getthisfirst">
					<h2>Get This First</h2>
					<div class="img"></div>
					<div class="free"></div>
					<form name="reg" id="reg" action="" method="POST">
                     <input type="hidden" name="singup" value="1">
					<ul>
					<li><label>Name:</label><input type="text" name="free_name" id="free_name"></li>
					<li><label>Email:</label><input type="text" name="free_email" id="free_email"></li>
					<li><input type="button" class="button" value="" onclick="return blogPageFreeTrail(this)"></li>
					<li><div class="spam-icon">No Spam Guarantee</div></li>
					</ul>
					 </form>
				</aside>
				<div style="clear:both; height:50px"></div>
				<aside id="categories" class="categories">
					<h2 class="widget-title">Categories</h2>
					<ul style="list-style:none">
					 <?php $categories = get_categories( $args ); 
					// print_r($categories);
						foreach($categories as $cat){?> 
						<li class="cat-item cat-item-1"><a href="<?php echo get_category_link( $cat->term_id );?>"><?php echo $cat->name?></a></li>
						<?php }?>
					</ul>
				</aside>
				<aside id="RecentPosts" class="recentposts">
					<h2 class="widget-title">Recent Posts</h2>
					<ul>
					<?php
						$getRecentPost=mysql_query("SELECT * FROM `".$wpdb->prefix."posts` WHERE post_status = 'publish' AND post_type = 'post' order by post_date desc limit 0,3");

		 while($fetRecentPost=mysql_fetch_object($getRecentPost)){
		 $cont =get_post_custom_values('short_description', $fetRecentPost->ID);
	if(strpos($cont,'<img')!== FALSE) {
    	$img_start = strpos($cont[0],'<img');
        $start = strpos($cont[0],'src="',$img_start)+5;
        $end = strpos($cont[0],'"',$start);
        echo $path1 = substr($cont[0],$start,$end-$start);
    }
					?>
					<li><?php if($path1<>''){?><div class="fl"><img src="<?php echo path1 ?>"></div><?php }?>
						<div class="fr"><h3><?php echo $fetRecentPost->post_title?></h3>
						<h4><?php echo date('F d, Y',strtotime($fetRecentPost->post_date))?>   - <?php echo $fetRecentPost->comment_count?> Comments</h4></div>
					<?php }?>
					</ul>
				</aside>

				<aside id="Subscribe" class="subscribe">
					<h3 class="widget-title">Subscribe to this Blog</h3>
					<form>
					<ul>
					<li><input placeholder="E-maill Address"></li>
					<li><input type="button" class="button" value="Subscribe"></li>
					</ul>
					 </form>
				</aside>

		</div><!-- #secondary .widget-area -->
<?php //endif; ?>