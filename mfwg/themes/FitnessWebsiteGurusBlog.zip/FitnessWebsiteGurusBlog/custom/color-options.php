<?php
//global $wpdb;
include("functions.php");
if($_GET['act']=='setColor'){
	echo setasFeaturedColor($_GET['id']);
}
/*if($_POST['aboutsubmit']){
	echo updateContactForm($_POST,"about",1);
}
if($_POST['emailsubmit']){
	echo updateContactForm($_POST,"email",2);
}*/
/*if($_POST['phonesubmit']){
	echo updateContactForm($_POST,"phone",3);
}
if($_POST['embedsubmit']){
	echo updateContactForm($_POST,"embed",4);
}*/
?>
<script type="text/javascript">
function setThisColor(id){
//alert("tt");
	var r=confirm("Do You Want set this Color?");
	if (r==true){
		window.location='admin.php?page=theme-options&act=setColor&id='+id;
	}else{
		window.location='admin.php?page=theme-options';
	}
}
</script>
<style type="text/css">
.theme-options-table{} 
.theme-options-table td{ padding-left:10px} 
</style>
<div>&nbsp;</div>
<?php echo getColorOptions();?>
<br>
<?php /* ----------------------------------- about content----------------------------------------*/?>
<?php /*?><table class="theme-options-table" width="50%" cellpadding="0" cellspacing="0" style="border:1px solid #ccc">
<tr style="background:#ccc;"><td><h2>About Us</h2></td></tr>
<tr><td>
<?php echo getContactFormTextArea("about",1);?>
</td></tr></table>
<br><?php */?>
<?php /* ----------------------------------- email content----------------------------------------*/?>
<?php /*?><table class="theme-options-table" width="50%" cellpadding="0" cellspacing="0" style="border:1px solid #ccc">
<tr style="background:#ccc;"><td><h2>Email Id</h2></td></tr>
<tr><td>
<?php echo getContactFormText("email",2);?>
</td></tr></table><?php */?>
<br>
<?php /* ----------------------------------- phone content----------------------------------------*/?>
<?php /*?><table class="theme-options-table" width="50%" cellpadding="0" cellspacing="0" style="border:1px solid #ccc">
<tr style="background:#ccc;"><td><h2>Phone Number</h2></td></tr>
<tr><td>
<?php echo getContactFormText("phone",3);?>
</td></tr></table>
<br><?php */?>
<?php /* ----------------------------------- embed content----------------------------------------*/?>
<?php /*?><table class="theme-options-table" width="50%" cellpadding="0" cellspacing="0" style="border:1px solid #ccc">
<tr style="background:#ccc;"><td><h2>Embed Code</h2></td></tr>
<tr><td>
<?php echo getContactFormTextArea("embed",4);?>
</td></tr></table><?php */?>