<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content after
 *
 * @package WordPress
 * @subpackage FitnessWebsiteGurus-Blog
 * @since Twenty Eleven 1.0
 */
?>

	</div><!-- #main -->
 
</div><!-- #page -->
</div><!-- #page -->
<style>
.sec ul li a{ color:#fff; text-decoration:none}
</style>
	<footer id="colophon" role="contentinfo">
		<div class="footer">
			<section class="footer-top"> 
				<section class="footer-links"> 
					<aside id="Blogroll" class="sec"> 
						
						<?php //get_links_list('order'); ?>
						<?php wp_list_bookmarks(); ?>
						 
					</aside>
					<aside id="Categories" class="sec"> 
						<h2>Categories</h2> 
						<ul>
						<?php $categories1 = get_categories( $args ); 
					// print_r($categories);
						foreach($categories1 as $cat1){?> 
						<li><a  style="color: rgb(255, 255, 255); text-decoration: none;" href="<?php echo get_category_link( $cat1->term_id );?>"><?php echo $cat1->name?></a></li>
						<?php }?> 
						</li> 
						</ul>  
					</aside>
					<aside id="Archives" class="sec"> 
						<h2>Archives</h2> 
						<ul>
						<?php echo wp_get_archives('type=postbypost&limit=6&format=html'); ?>
						</ul>  
					</aside>  
				</section>
				<section class="contact"> 
					<h2>Contact Us</h2> 
						<ul>
						<li><input><label>Name *</label></li>
						<li><input><label>Email *</label></li> 
						<li><textarea></textarea></li> 
						<li><input type="button" class="button"></li>  
						</ul>  
				</section>
			</section>
			<?php
				/* A sidebar in the footer? Yep. You can can customize
				 * your footer with three columns of widgets.
				 */
				if ( ! is_404() )
					get_sidebar( 'footer' );
			?>

			<section class="copyright">
			<div class="copyright-area">
			<div class="copy">&copy; <?php echo date("Y")?> <a href="http://www.fitnesswebsitegurus.com">Fitness Website Design</a> By Fitness Website Gurus</div>
			<div class="power">  Powered by: Fitness Website Gurus  </div> 
			</div>
			</section>
		</div>
	</footer><!-- #colophon -->
<?php wp_footer(); ?>

</body>
</html>