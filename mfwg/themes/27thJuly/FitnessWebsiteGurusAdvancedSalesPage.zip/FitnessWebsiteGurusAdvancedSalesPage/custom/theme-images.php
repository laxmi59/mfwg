<?php 
include("functions.php");
// header
if($_POST['headersubmit']){
	return AddImages($_POST,1,'header_');
}
// logo
if($_POST['logosubmit']){
	return AddImages($_POST,2,'logo_');
}
// phone
if($_POST['phonesubmit']){
	return AddImages($_POST,3,'phone_');
}
// profile
if($_POST['profilesubmit']){
	return AddImages($_POST,4,'profile_');
}
if($_GET['act']=='delete'){
	echo deleteCustomImage($_GET['id']);
}
if($_GET['act']=='featured'){
	echo setasFeaturedImage($_GET['id']);
}
switch ($_GET['type']) {
    case 1:
        $imgtype="Header";
        break;
    case 2:
        $imgtype="Logo";
        break;
    case 3:
        $imgtype="Phone";
        break;
	case 4:
        $imgtype="Profile";
        break;
}

switch ($_GET['status']) {
    case 1:
        $msg="Upload ".$imgtype." Image File. It should not be empty";
        break;
    case 2:
        $msg="Uploded ".$imgtype." Image file must be jpg, png or gif";
        break;
    case 3:
        $msg= $imgtype." Image Title should not be empty";
        break;
	case 5:
        $msg="Uploded ".$imgtype." Image file successfully";
        break;
}

?>
<script type="text/javascript">
// validations
function trimfun(stringToTrim) {
	return stringToTrim.replace(/^\s+|\s+$/g,"");
}
function isNotEmpty(fname,txt){
	if(trimfun(fname.value)=="")	{
		alert(txt);
		fname.focus();
		return true;
	}
	return false;
}
function validateForm(reg){
alert("hi");
//var types=reg.itemtype;
	//if(isNotEmpty(reg.header_title,"Title should not be Empty")){return false}
	//if(isNotEmpty(reg.header_image,"Image should not be Empty")){return false}
}
function setAsFeatured(id){
	var r=confirm("Do You Want set this Image as Featured ?");
	if (r==true){
		window.location='admin.php?page=custom-theme-images&act=featured&id='+id;
	}else{
		window.location='admin.php?page=custom-theme-images';
	}
}
function deletCustomImage(id){
	var r=confirm("Do You Want to delete this Image?");
	if (r==true){
		window.location='admin.php?page=custom-theme-images&act=delete&id='+id;
	}else{
		window.location='admin.php?page=custom-theme-images';
	}
}
</script>
<style>
td{padding-left:10px}
</style>
<div>&nbsp;</div>
<div style="color:red; text-align:center; font-weight:bold"><?php echo $msg;?></div>
<div>&nbsp;</div>
<table width="90%" cellpadding="0" cellspacing="0" style="border:1px solid #ccc">
<tr style="background:#ccc;"><td><h2>Header Images</h2></td></tr>
<tr><td>
<?php /* ----------------------------------- header images----------------------------------------*/?>

<?php echo AddImagesForm(1,"header");?>
<div>&nbsp;</div>
<h2 align="center">Header Images List</h2>
<?php echo getImages(1,"header");?>
</td></tr></table>
<br>
<table width="90%" cellpadding="0" cellspacing="0" style="border:1px solid #ccc">
<tr style="background:#ccc;"><td><h2>Logo Images</h2></td></tr>
<tr><td>
<?php /* ----------------------------------- logo images----------------------------------------*/?>
<?php echo AddImagesForm(2,"logo");?>
<div>&nbsp;</div>
<h2 align="center">Logo Images List</h2>
<?php echo getImages(2,"logo");?>
</td></tr></table>
<br>
<table width="90%" cellpadding="0" cellspacing="0" style="border:1px solid #ccc">
<tr style="background:#ccc;"><td><h2>Phone Images</h2></td></tr>
<tr><td>
<?php /* ----------------------------------- phone images----------------------------------------*/?>
<?php echo AddImagesForm(3,"phone");?>
<div>&nbsp;</div>
<h2 align="center">Phone Images List</h2>
<?php echo getImages(3,"phone");?>
</td></tr></table>
<br>
<table width="90%" cellpadding="0" cellspacing="0" style="border:1px solid #ccc">
<tr style="background:#ccc;"><td><h2>Profile Images</h2></td></tr>
<tr><td>
<?php /* ----------------------------------- profile images----------------------------------------*/?>
<?php echo AddImagesForm(4,"profile");?>
<div>&nbsp;</div>
<h2 align="center">Profile Images List</h2>
<?php echo getImages(4,"profile");?>
</td></tr></table>
<br>








