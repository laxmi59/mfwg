<?php
/**
 * The Sidebar containing the main widget area.
 *
 * @package WordPress
 * @subpackage FitnessWebsiteGurus-Blog
 * @since Twenty Eleven 1.0
 */

//$options = twentyeleven_get_theme_options();
//$current_layout = $options['theme_layout'];

//if ( 'content' != $current_layout ) :
?>
<div id="secondary" class="widget-area" role="complementary"  > 
<aside id="archives" class="getstartedform">  
			<form>
				<ul>
					<li><p>Just enter your information below and receive a free 1 week trial.</p></li>
					<li><label>Name:</label><input></li>
					<li><label>Email:</label><input></li>
					<li class="ph"><label>Phone:</label><input> - <input> - <input></li>
					<li><input type="button" class="button"></li> 
				</ul> 
			 </form>
		</aside>
	<aside id="profile" class="profile">
		<img src="<?php if(getcustomImage(4)<>'') echo getcustomImage(4); else echo bloginfo('url')."/wp-content/themes/".get_template()."/images/header_images/profile_1.png"?>" />		
		<h2>About</h2>
		<ul><li><?php $activeabout=mysql_fetch_object(mysql_query("select * from `".$wpdb->prefix."custom_contacts` where title='About' and status=1"));
		echo stripslashes($activeabout->content);
		?> </li>
		<li><?php $activeemail=mysql_fetch_object(mysql_query("select * from `".$wpdb->prefix."custom_contacts` where title='Email' and status=1"));
		echo "<strong>Email</strong> : <a href='mailto:".stripslashes($activeemail->content)."'>".stripslashes($activeemail->content)."</a>";
		?> 
		<br> <?php $activephone=mysql_fetch_object(mysql_query("select * from `".$wpdb->prefix."custom_contacts` where title='Phone' and status=1"));
		echo "<strong>Phone Number : </strong>".stripslashes($activephone->content);
		?></li>
		</ul>
	</aside>
	<div class="whline"></div>
	<aside id="tst" class="tst"> 
		<h2>Testimonials</h2>
		<ul>		
		<?php 
		$catid=get_category_by_slug( 'testimonial' );
		//echo $catid->term_id;
		$getTestimonials=mysql_query("SELECT * FROM ".$wpdb->prefix."posts wp, wp_term_relationships wtr WHERE wtr.term_taxonomy_id = ".$catid->term_id." AND object_id = wp.ID order by wp.post_date desc");
		while($fetTestimonials=mysql_fetch_object($getTestimonials)){?>
		<li><p><?php echo $fetTestimonials->post_content?> </p>
			<strong><?php echo $fetTestimonials->testimonial_name?></strong><br>
			<?php echo $fetTestimonials->testimonial_city?>
		</li>
		<?php }?>
		</ul>
	</aside>
				

		</div><!-- #secondary .widget-area -->
<?php //endif; ?>