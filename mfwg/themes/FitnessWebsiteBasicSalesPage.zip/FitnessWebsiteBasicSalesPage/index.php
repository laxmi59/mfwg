<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage FitnessWebsiteGurus-Blog
 */

get_header(); ?>
<?php get_sidebar(); ?>
		<div id="primary">
			<div id="content" role="main">
 			<div>
			<section class="title">
				<?php $home_title=mysql_fetch_object(mysql_query("select * from ".$wpdb->prefix."posts where post_name='home-headline'"));?>
				<h1><?php echo $home_title->post_content?></h1>
				<?php $home_subtitle=mysql_fetch_object(mysql_query("select * from ".$wpdb->prefix."posts where post_name='home-sub-headline'"));?>
				<h2><?php echo $home_subtitle->post_content?></h2>
				<div class="titlehline"></div>
			</section>
             <div>
				<?php $home_subtitle=mysql_fetch_object(mysql_query("select * from ".$wpdb->prefix."posts where `post_name`='home-body'"));?>
				<?php echo $home_subtitle->post_content?>
			</div>
			<?php $category = get_category_by_slug('testimonial-plus');?>
			 <?php $category = get_category_by_slug('testimonial-plus');?>
			<?php
				global $post;
				$args = array( 'numberposts' => 5, 'offset'=> 0, 'category' => $category->term_id );
				$myposts = get_posts( $args );
				if($myposts){
					foreach( $myposts as $post ) :	setup_postdata($post); ?>
						<section class="tstimonial">
                        <ul><li>
                        <h2><?php echo $post->post_title?></h2><div class="qoote"></div> <img src="<?php echo $post->testimonial_image_path."/".$post->testimonial_image?>"><?php echo $post->post_content?><strong><?php echo $post->testimonial_name?></strong><br><?php echo $post->testimonial_city?> </li> </ul><div class="shadow"></div></section>
				<?php endforeach; ?>
			<?php }?>        
			</div>
			</div><!-- #content -->
		</div><!-- #primary -->
<?php get_footer(); ?>